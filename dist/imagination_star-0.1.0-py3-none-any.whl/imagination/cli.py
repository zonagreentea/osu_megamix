def main():
    from .engine.core import run
    run()
