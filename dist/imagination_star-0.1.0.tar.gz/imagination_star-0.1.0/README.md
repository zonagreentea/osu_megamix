# imagination*

Standalone runtime (no osu!megamix required).

## Run (dev)
python -m imagination

## Install (editable)
pip install -e .
imagination
