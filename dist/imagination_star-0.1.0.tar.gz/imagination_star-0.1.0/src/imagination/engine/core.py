def run():
    print("[imagination*] boot OK (standalone).")
