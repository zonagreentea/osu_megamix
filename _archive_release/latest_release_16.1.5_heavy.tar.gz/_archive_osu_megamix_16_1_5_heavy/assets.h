#pragma once
unsigned char placeholder_png[] = {0x89, 0x50, 0x4E, 0x47}; // PNG header only
unsigned int placeholder_png_len = 4;
